<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Basic Grass Biom things 12" tilewidth="72" tileheight="72" tilecount="45" columns="9">
 <image source="./Basic Grass Biom things 12.png" width="648" height="360"/>
 <tile id="0">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="4">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="17">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="36">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="37">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="38">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="39">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="40">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
</tileset>
