<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Free_Chicken_House 1" tilewidth="72" tileheight="72" tilecount="1" columns="1">
 <image source="./Free_Chicken_House 1.png" width="72" height="72"/>
 <tile id="0">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
</tileset>
