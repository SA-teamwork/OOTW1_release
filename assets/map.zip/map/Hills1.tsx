<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Hills1" tilewidth="72" tileheight="72" tilecount="36" columns="6">
 <image source="./Hills1.png" width="432" height="432"/>
</tileset>
