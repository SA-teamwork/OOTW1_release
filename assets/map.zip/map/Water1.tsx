<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Water1" tilewidth="72" tileheight="72" tilecount="4" columns="4">
 <image source="./Water1.png" width="288" height="72"/>
 <tile id="0">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
 <tile id="3">
  <properties>
   <property name="block" value="1"/>
  </properties>
 </tile>
</tileset>
