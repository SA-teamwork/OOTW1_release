<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Grass1" tilewidth="72" tileheight="72" tilecount="20" columns="5">
 <image source="../../Sprout Lands - Sprites - Basic pack/Sprout Lands - Sprites - Basic pack/Tilesets/Grass1.png" width="360" height="288"/>
</tileset>
