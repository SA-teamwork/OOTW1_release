<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Water1" tilewidth="72" tileheight="72" tilecount="4" columns="4">
 <image source="../../Sprout Lands - Sprites - Basic pack/Sprout Lands - Sprites - Basic pack/Tilesets/Water1.png" width="288" height="72"/>
</tileset>
