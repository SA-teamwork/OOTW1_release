<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Wood Bridge 1" tilewidth="72" tileheight="72" tilecount="15" columns="5">
 <image source="../../Sprout Lands - Sprites - Basic pack/Sprout Lands - Sprites - Basic pack/Objects/Wood Bridge 1.png" width="360" height="216"/>
</tileset>
